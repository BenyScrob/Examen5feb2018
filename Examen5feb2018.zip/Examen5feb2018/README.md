Creati un repository pe GitHub si commitati modificarile la fiecare pas cu textul sugerat :

1 Creati cu Balsamique versiunea mobile pentru acest design (0.5p) - GitHub Commit cu textul (`Balsamique`)
2. Transformati PSD `sevenoaks.psd` in HTML si CSS (pentru CSS scrieti codul SASS) (2p CSS) sau (4p SASS) nu se poate amesteca CSS cu SASS, ori CSS ori SASS
2.1 Versiune Mobile (0.5p CSS) (1p SASS) - GitHub Commit cu textul (`Versiune Mobile / CSS sau SASS`)
2.2 Versiune Tableta (0.5p CSS) (1p SASS) - GitHub Commit cu textul (`Versiune Tableta / CSS sau SASS`)
2.3 Versiune Desktop (1p CSS) (2p SASS) - GitHub Commit cu textul (`Versiune Desktop/ CSS sau SASS`)
3. In partea de header includeti zona de slider cu doua slideuri diferite (poate sa fie diferita numai imaginea de background de exemplu). (2p) - GitHub Commit cu textul (`Slider`)
4. Pentru textul de sub `Stories`, `Give Online` si `Prayer`, din dreapta cel cu `Lorem Ipsum` integrati Bacon Ipsum API : https://baconipsum.com/json-api/ pentru a pune textul (2p) - GitHub Commit cu textul (`Bacon Ipsum API`)
5. Generati manifestul PWA pentru pagina HTML. (0.5p) - GitHub Commit cu textul (`PWA`)

Trimiteti linkul la GitHub pe adresa de email : radu.crisan@emanuel.ro pana pa sfarsitul examenului. Commiturile date dupa incheierea examenului nu se vor lua in considerare.
1p din oficiu